import socket

def client():
    host = socket.gethostname()
    port = 8080
    s = socket.socket()
    s.connect((host, port))
    print()
    filename = input("Enter filename: ")
    s.send(filename.encode())
    if "." not in filename:
        print("Server Response --> No extension given with the file.")
        print()
        exit()
    ext = filename.split(".")[1]
    if ext != "txt":
        print("Server Response --> Incorrect File Format")
        print()
        exit()
    data = s.recv(1024).decode()
    
    if data[:3] == "404":
        print("Server Response --> Requested File Not Found")
        print()
        exit()
    else:
        # Create a new file with the name of the file given by the client and write the data received from the server into the file in folder named "client_files".
        with open("Downloads/"+filename, "w") as f:
            f.write(data)
        print("Server Response --> File received successfully in Downloads folder")
        print()
    s.close()

if __name__ == "__main__":
    client()