Implement File Transfer Protocol (FTP) in client-server communication. When the client requests a file:

a. If the requested file is available with the server, the server sends back the file to DOWNLOADS folder.

b. If the requested file is not available with the server, the server should send an error message to the client saying “Requested File Not Found”.

c. If the requested file has an incorrect extension, the server should communicate “Incorrect File Format” to the client.

d. If the requested file does not have any kind of extension, the server communicates "No extension given with the file."

Note: Use .txt as the valid extension for the files communicated.

//////////////////////////////////////////////////////////// STEPS /////////////////////////////////////////////////////////////////////////////////
Run client on terminal on same path.

Run server on another terminal on same path.

Ask the user to enter the filename which he/she is looking for.

Now, finally after pressing enter you will get the updates from server side.