import socket
def server():
    host = socket.gethostname()
    port = 8080
    s = socket.socket()
    s.bind((host, port))
    s.listen(1)
    print()
    print("Server listening on port", port)
    while True:
        conn, addr = s.accept()
        print()
        print("New Connection from", addr)
        filename = conn.recv(1024).decode()
        # If no extension found then return the error no extension found.
        if "." not in filename:
            print("--> Error!! No extension given with the file.")
            conn.send("--> No extension given with the file.".encode())
            conn.close()
            continue
        ext = filename.split(".")[1]
        if ext != "txt":
            print("--> No file sent as 'incorrect file format'")
            conn.send("--> Incorrect File Format".encode())
            conn.close()
            continue
        try:
            # If the file name matches an existing file in directory send the content inside the file to the client.
            with open(filename, "r") as f:
                data = f.read()
                conn.send(data.encode())
            print("--> File sent successfully")
            print()
            conn.close()
            continue
        except:
            print("--> No file sent as 'file not found'")
            conn.send("404".encode())
        conn.close()
    
if __name__ == "__main__":
    server()
    