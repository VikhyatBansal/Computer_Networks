import socket
import os

def client():
    host = socket.gethostname()
    port = 8080
    s = socket.socket()
    s.connect((host, port))
    
    final_req = ""
    print()
    req_type = input("Enter request type: ")
    req_type = req_type.strip().upper()
    
    if req_type != "GET" and req_type != "POST" and req_type != "PUT" and req_type != "DELETE":
        print("Invalid Request Type")
        exit()
        
    file_name = input("Enter file name: ")
    
    if req_type == "GET" or req_type == "DELETE":
        final_req = req_type + " " + file_name
    else:
        data_to_enter = input("Enter data to enter: ")
        final_req = req_type + " " + file_name + " " + data_to_enter
        
    s.send(final_req.encode())
    
    # Print the message received from the server.
    print()
    if req_type == "GET":
        print("File content received from server: ")
        print()
    print(s.recv(1024).decode())
    print()
    s.close()
    
if __name__ == "__main__":
    client()
      