import java.util.*;
import java.lang.*;
import java.io.*;


// Coin change problem using top down approach with memoization

public class DynamicProgramming{
    public int CoinChangeTopDownApproach(int n,int[] coins,int t,int[] dp){
       if (n == 0){
          return 0;
       }
       if (dp[n] != 0){
          return dp[n];
       }
       int ans = Integer.MAX_VALUE;
       for (int i = 0; i < t; i++){
          if (n - coins[i] >= 0){
             int subprob = CoinChangeTopDownApproach(n - coins[i], coins, t, dp);
             ans = Math.min(ans, subprob + 1);
       }
       
    }
    dp[n] = ans;
    return dp[n];
    }

    public static void main(String[] args){
        DynamicProgramming dp = new DynamicProgramming();
        int N = 6;
        int[] coins = { 1, 3, 4 };
        int[] dp1 = new int[N+1];
        int t = coins.length;
      //   int res = dp.CoinChangeTopDownApproach(N, coins, t, dp1);
      //   System.out.println(res);
         dp.CoinChangeTopDownApproach(N, coins, t, dp1);
         for (int i = 0; i < dp1.length; i++){
            System.out.print(dp1[i] + " ");
         }
     }
 }



 