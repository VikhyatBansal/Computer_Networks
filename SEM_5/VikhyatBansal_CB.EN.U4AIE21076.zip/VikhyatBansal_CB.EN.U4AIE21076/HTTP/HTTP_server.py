import socket
import os 

def server():
    host = socket.gethostname()
    port = 8080
    s = socket.socket()
    s.bind((host, port))
    s.listen(1)
    
    print()
    print("Server listening on port", port)
    
    while True:
        conn, addr = s.accept()
        print()
        print("New Connection from", addr)
        client_req = conn.recv(1024).decode()
        if "GET" in client_req:
            filename = client_req.split(" ")[1] 
            try:
                # Print the content of the file on the client side.
                print()
                with open(filename, "r") as f:
                    data = f.read()
                    conn.send(data.encode())
                print("--> File being displayed on client side")
                print()
                conn.close()
                # break
            except:
                print("--> No content being displayed as resource 'file not found'")
                conn.send("From Server --> Status Code: 404 File not Found".encode())
            conn.close()
            
        elif "POST" in client_req:
            # Create a new file with the name of the file given by the client and write the data received from the client into the file.
            filename = client_req.split(" ")[1]
            # Data starts from 2nd space in the client request and goes till the end in client request.
            data = client_req.split(" ")[2:]
            data = " ".join(data)
            try:
                with open(filename, "x") as f:
                    f.write(data)
                conn.send("From Server --> Status Code: 201 Created".encode())
                print("--> File created successfully")
                print()
                conn.close()
                # break
            except:
                None
                
        elif "PUT" in client_req:
            filename = client_req.split(" ")[1]
            data = client_req.split(" ")[2:]
            data = " ".join(data)
            # If filename not in directory create a new file with the name of the file given by the client and write the data received from the client into the file.
            try:
                with open(filename, "x") as f:
                    f.write(data)
                print("--> File was not found so new resource file created successfully and content updated in it!!!")
                conn.send("From Server --> Status Code: 201 Created".encode())
                print()
                conn.close()
                # break
            except:
                # If filename in directory update the file with the name of the file given by the client and write the data received from the client into the file.
                with open(filename, "w") as f:
                    f.write(data)
                # Update the name of the file to filename_updated with previous extension.
                os.rename(filename, filename.split(".")[0]+"_updated."+filename.split(".")[1])
                conn.send("From Server --> Status Code: 200 OK".encode())
                print("--> Existing File updated successfully")
                print()
                conn.close()
                # break
                
        elif "DELETE" in client_req:
            # If the file name matches an existing file in directory delete the file.
            filename = client_req.split(" ")[1]
            try:
                os.remove(filename)
                conn.send("From Server --> Status Code: 200 OK".encode())
                print("--> File deleted successfully")
                print()
                conn.close()
                # break
            except:
                # If file not found tell the client file not found.
                print("--> File not deleted as 'file not found'")
                conn.send("From Server --> Status Code: 404 File not found.".encode())
                
        else:
            conn.send("Error: 400 Bad Request".encode())
            print("--> Invalid request")
        conn.close()
        
        
if __name__ == "__main__":
    server()