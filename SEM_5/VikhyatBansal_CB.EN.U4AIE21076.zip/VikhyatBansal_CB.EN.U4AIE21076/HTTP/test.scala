// print sierpinski triangle

object sierpinski{
    def main(args: Array[String]){
        val n = 5
        for (i <- 0 to n){
        for (j <- 0 to n-i){
            print(" ")
        }
        for (j <- 0 to i){
            print("* ")
        }
        println()
        }
    }
}