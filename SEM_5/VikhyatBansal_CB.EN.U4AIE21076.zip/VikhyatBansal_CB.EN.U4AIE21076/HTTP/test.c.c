// Printing number from 1 to 50

# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>

int main(){
    int i = 1;
    while(i<=50){
        printf("%d ",i);
        i++;
    }    
}

// We can move the code 1 file to any other location to get the desired output.