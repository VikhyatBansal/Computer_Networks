2. Implement Hypertext Transfer Protocol (HTTP) in client-server communication. The program should include the following functions:

a. GET: The contents of the requested resource should be displayed in the client. If the requested resource is not available with the server, the server should communicate an error message to the client.

b. POST: The server should create a new resource corresponding to the data communicated by the client.

c. PUT: Client communicates the name of the resource to be updated, along with the updated content. The server updates the content of the said resource accordingly. If the said resource is not available with the server, the server creates a new resource with the updated content.

d. DELETE: Client communicates the name of the resource to be deleted in the server. The server performs the deletion accordingly. If the corresponding resource is not present in the server, an error message should be communicated to the client.

The code can be used to get file with any extension containing some kind of resource that can be displayed on terminal.

Note: The folder contains many other extension files too, which can have the above requests performed on them by server.

//////////////////////////////////////////////////////////// STEPS /////////////////////////////////////////////////////////////////////////////////
Run client on terminal on same path.

Run server on another terminal on same path.

Ask the user to enter request type, filename and depending upon the request also write the content that is to be added in the file.

Now, finally after pressing enter you will get the updates from server side.

